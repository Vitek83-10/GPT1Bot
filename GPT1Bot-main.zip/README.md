# GPT1Bot

Telegram bot for token monitoring.